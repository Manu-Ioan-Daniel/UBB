#ifndef OFERTA_H
#define OFERTA_H
typedef struct{
    char tip[12];
    float suprafata;
    char adresa[101];
    float pret;
}Oferta;

#endif //OFERTA_H