package services;
import models.Hotel;
import models.Location;
import models.SpecialOffer;
import repo.HotelRepo;
import repo.LocationRepo;
import repo.SpecialOfferRepo;
import utils.observer.Observable;

import java.time.LocalDate;
import java.util.List;

public class MainService extends Observable {
    private final LocationRepo locationRepo;
    private final HotelRepo hotelRepo;
    private final SpecialOfferRepo specialOffersRepo;

    public MainService(LocationRepo locationRepo, HotelRepo hotelRepo, SpecialOfferRepo specialOffersRepo) {
        this.locationRepo = locationRepo;
        this.hotelRepo = hotelRepo;
        this.specialOffersRepo = specialOffersRepo;
    }

    public List<Location> findAllLocations() {
        return locationRepo.findAll();
    }

    public List<Hotel> findHotelsByLocation(String locationName){
        return hotelRepo.findByLocation(locationName);
    }

    public List<SpecialOffer> findSpecialOffers(Long hotelId, LocalDate date){
        return specialOffersRepo.findSpecialOffersInTimeline(hotelId, date);
    }
}
