package enums;

public enum ChangeEvent {
    NOTIFICATION,
}
