package enums;

public enum HotelType {
    FAMILY,
    TEENAGERS,
    OLDPEOPLE
}
