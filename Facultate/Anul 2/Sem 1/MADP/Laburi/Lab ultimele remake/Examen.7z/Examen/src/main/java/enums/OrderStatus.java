package enums;

public enum OrderStatus {
    PENDING,
    IN_PROGRESS,
    FINISHED
}
