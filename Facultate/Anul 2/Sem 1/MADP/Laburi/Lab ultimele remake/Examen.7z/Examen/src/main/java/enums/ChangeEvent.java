package enums;

public enum ChangeEvent {
    NOTIFICATION,
    ORDER_ADDED, ORDER_UPDATED, ORDER_FINISHED
}
